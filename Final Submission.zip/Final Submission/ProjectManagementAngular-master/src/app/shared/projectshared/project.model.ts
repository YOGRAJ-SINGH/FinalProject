export class Project {

        projectId: number;
        projectName: string;
        startDate: string;
        endDate: string;
        priority: number;
        taskNumber: number;
        completedTaskNumber: number;
        manager: string;
        userId: number;
    
} 
