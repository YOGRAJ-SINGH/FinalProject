export class User {
    userId: number;
	firstName: string;
	lastName: string;
	employeeId: string;
}
 